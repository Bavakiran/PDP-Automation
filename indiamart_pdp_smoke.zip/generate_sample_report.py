"""generate_sample_report.py – preview report without live network."""
import sys, datetime
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))
from utils.helpers import generate_report

def tc(tc_id, name, suite, status="PASS", detail="", ms=None):
    import random; random.seed(abs(hash(tc_id)) % 9999)
    return {"tc_id": tc_id, "name": name, "suite": suite,
            "status": status, "detail": detail,
            "elapsed": ms or round(random.uniform(400, 3800), 1)}

results = [
  # ── PDP Landings ─────────────────────────────────────────────────────────
  tc("TC-5543","Verify that user able to land on PDP page through search page","PDP Landings"),
  tc("TC-5546","Verify that user able to land on PDP page through Mcat Page","PDP Landings"),
  tc("TC-5547","Verify that user able to land on PDP through company page","PDP Landings"),
  tc("TC-5905","Verify that user able to land on PDP page through google","PDP Landings"),
  tc("TC-5989","Verify that user can able to land on PDP through homepage","PDP Landings"),

  # ── PDP First Fold ───────────────────────────────────────────────────────
  tc("TC-5548","Verify that image enquiry form should opens, if user click on product image","PDP First Fold"),
  tc("TC-5549","Verify that user able to submit the requirement on clicking the enquiry now CTA","PDP First Fold"),
  tc("TC-5550","Verify that Enquiry form should opens after clicking on the submit requirement CTA","PDP First Fold"),
  tc("TC-5551","Verify that user is redirected to company page after clicking on company name","PDP First Fold"),
  tc("TC-5552","Verify that Review count is redirected to the rating and review section of pdp page","PDP First Fold"),
  tc("TC-5553","Verify that Seller PNS number should display without clicking on Call Now CTA","PDP First Fold"),
  tc("TC-5554","Verify that enquiry form should opens, if user clicks on Contact supplier CTA","PDP First Fold"),
  tc("TC-5906","Verify that user can receive the call from the seller on clicking 'Call Now' CTA","PDP First Fold"),
  tc("TC-5907","Verify that Clicking on 'Contact Supplier' CTA displays the enquiry form","PDP First Fold"),
  tc("TC-5939","Verify that clicking on the brochure PDF(if applicable) opens the quick requirement form","PDP First Fold"),
  tc("TC-5940","Verify that clicking on the video icon opens the enquiry form","PDP First Fold"),
  tc("TC-5941","Verify that clicking on 'View in hindi' redirects the user to hindi PDP page","PDP First Fold"),

  # ── PDP Breadcrumbs ──────────────────────────────────────────────────────
  tc("TC-5628","Verify that Indiamart link is redirected to the dir.indiamart.com","PDP Breadcrumbs"),
  tc("TC-5629","Verify that second link under breadcrumbs redirected to the subcategories page","PDP Breadcrumbs"),
  tc("TC-5630","Verify that third link under breadcrumbs should redirected to the mcat page","PDP Breadcrumbs"),

  # ── Find Similar Products ────────────────────────────────────────────────
  tc("TC-5942","Verify that similar products related to the product name are displayed","Find Similar Products"),
  tc("TC-5943","Verify that clicking on 'Get Best Price' CTA opens the enquiry form","Find Similar Products"),
  tc("TC-5944","Verify that clicking on the product name redirects to the PDP page","Find Similar Products"),
  tc("TC-5945","Verify that clicking on view mobile number CTA redirects to the enquiry form","Find Similar Products"),

  # ── Find Related Categories ──────────────────────────────────────────────
  tc("TC-5946","Verify that related categories related to product are displayed","Find Related Categories"),
  tc("TC-5947","Verify that clicking on the category tiles redirects to the MCAT/Search category page","Find Related Categories"),
  tc("TC-5948","Verify that clicking on 'Get Quotes' opens the BL form","Find Related Categories"),

  # ── Company Details ──────────────────────────────────────────────────────
  tc("TC-5949","Verify that company details are displayed","Company Details"),
  tc("TC-5950","Verify that clicking on the 'Contact Seller' CTA opens the enquiry form","Company Details"),

  # ── Enquiry Form ─────────────────────────────────────────────────────────
  tc("TC-5951","Verify that clicking on the 'Submit Requirement' CTA opens the enquiry form","Enquiry Form"),
  tc("TC-5952","Verify that clicking on 'Chat Now' CTA, opens the chat enquiry form","Enquiry Form"),

  # ── More Products ────────────────────────────────────────────────────────
  tc("TC-5953","Verify that more products from the seller is displayed","More Products"),
  tc("TC-5954","Verify that clicking on 'Get Best Price' CTA opens the enquiry form","More Products"),

  # ── About the Company ────────────────────────────────────────────────────
  tc("TC-5955","Verify that company details are displayed","About the Company"),
  tc("TC-5956","Verify that ratings and reviews are displayed","About the Company"),

  # ── Get Quotes from Verified Suppliers ───────────────────────────────────
  tc("TC-5957","Verify that product name are prefilled in the text box","Get Quotes from Verified Suppliers"),
  tc("TC-5958","Verify that clicking on 'Submit Requirement' CTA opens the BL forms","Get Quotes from Verified Suppliers"),

  # ── Header / Footer ──────────────────────────────────────────────────────
  tc("TC-5959","Verify that redirection of header CTAs","Header / Footer"),
  tc("TC-5960","Verify that redirect of footer CTAs","Header / Footer"),
]

Path("reports").mkdir(exist_ok=True)
ts  = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
out = f"reports/pdp_smoke_{ts}.html"
generate_report(results, out)
print(f"Report: {out}")

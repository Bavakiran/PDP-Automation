"""
main.py
────────────────────────────────────────────────────────────────────────────
IndiaMart PDP Daily Execution Smoke Test – Main Runner
TestLink Suite ID : 370946
Total TCs         : 39 across 11 sub-suites

Usage:
    python main.py                          # run all 11 suites
    python main.py --suite landings         # run only PDP Landings
    python main.py --suite firstfold
    python main.py --suite breadcrumbs
    python main.py --suite similar
    python main.py --suite categories
    python main.py --suite company
    python main.py --suite enquiry
    python main.py --suite moreproducts
    python main.py --suite aboutcompany
    python main.py --suite getquotes
    python main.py --suite headerfooter
    python main.py --headed                 # visible browser
────────────────────────────────────────────────────────────────────────────
"""
from __future__ import annotations
import sys, argparse, time, datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from playwright.sync_api import sync_playwright
from config import HEADLESS, VIEWPORT, NAV_TIMEOUT, USER_AGENT
from utils.helpers import generate_report

# ── Import all 11 test modules ────────────────────────────────────────────
from tests import (
    test_01_pdp_landings      as m01,
    test_02_pdp_first_fold    as m02,
    test_03_pdp_breadcrumbs   as m03,
    test_04_find_similar_products   as m04,
    test_05_find_related_categories as m05,
    test_06_company_details   as m06,
    test_07_enquiry_form      as m07,
    test_08_more_products     as m08,
    test_09_about_the_company as m09,
    test_10_get_quotes        as m10,
    test_11_header_footer     as m11,
)

SUITE_MAP = {
    "landings":     ("PDP Landings (5 TCs)",                        m01),
    "firstfold":    ("PDP First Fold (12 TCs)",                     m02),
    "breadcrumbs":  ("PDP Breadcrumbs (3 TCs)",                     m03),
    "similar":      ("Find Similar Products (4 TCs)",               m04),
    "categories":   ("Find Related Categories (3 TCs)",             m05),
    "company":      ("Company Details (2 TCs)",                     m06),
    "enquiry":      ("Enquiry Form (2 TCs)",                        m07),
    "moreproducts": ("More Products (2 TCs)",                       m08),
    "aboutcompany": ("About the Company (2 TCs)",                   m09),
    "getquotes":    ("Get Quotes from Verified Suppliers (2 TCs)",  m10),
    "headerfooter": ("Header / Footer (2 TCs)",                     m11),
}


# ── Pretty print helpers ──────────────────────────────────────────────────
def _banner(msg: str, char: str = "═", width: int = 72):
    print(f"\n{char * width}\n  {msg}\n{char * width}")


def _print_result(r: dict):
    icon = {"PASS": "✅", "FAIL": "❌", "SKIP": "⏭"}.get(r["status"], "?")
    detail = f"  ↳ {r['detail'][:90]}" if r["detail"] else ""
    print(f"    {icon}  [{r['tc_id']}]  {r['name'][:65]}{detail}")


# ── Suite runner ──────────────────────────────────────────────────────────
def run_suite(browser, label: str, module, headed: bool) -> list[dict]:
    context = browser.new_context(
        viewport=VIEWPORT,
        user_agent=USER_AGENT,
        java_script_enabled=True,
        ignore_https_errors=True,
    )
    page = context.new_page()
    page.set_default_navigation_timeout(NAV_TIMEOUT)
    page.set_default_timeout(20_000)

    _banner(f"▶  {label}", char="─")
    t0 = time.perf_counter()
    results = module.run(page)
    elapsed = time.perf_counter() - t0

    passed = sum(1 for r in results if r["status"] == "PASS")
    failed = sum(1 for r in results if r["status"] == "FAIL")
    print(f"\n  ✅ {passed} passed  |  ❌ {failed} failed  |  ⏱ {elapsed:.1f}s\n")
    for r in results:
        _print_result(r)

    context.close()
    return results


# ── Main ──────────────────────────────────────────────────────────────────
def main():
    parser = argparse.ArgumentParser(
        description="IndiaMart PDP Daily Execution Smoke Test Runner")
    parser.add_argument("--suite",
                        choices=list(SUITE_MAP.keys()) + ["all"],
                        default="all",
                        help="Which sub-suite to run (default: all)")
    parser.add_argument("--headed", action="store_true",
                        help="Run with visible browser window")
    args = parser.parse_args()

    keys = list(SUITE_MAP.keys()) if args.suite == "all" else [args.suite]
    all_results: list[dict] = []
    start = time.perf_counter()

    _banner("IndiaMart PDP Smoke Test  |  TestLink Suite 370946  |  39 TCs")

    with sync_playwright() as pw:
        browser = pw.chromium.launch(
            headless=not args.headed,
            slow_mo=0,
            args=["--disable-blink-features=AutomationControlled",
                  "--no-sandbox"]
        )
        for key in keys:
            label, module = SUITE_MAP[key]
            results = run_suite(browser, label, module, args.headed)
            all_results.extend(results)
        browser.close()

    total   = len(all_results)
    passed  = sum(1 for r in all_results if r["status"] == "PASS")
    failed  = sum(1 for r in all_results if r["status"] == "FAIL")
    skipped = sum(1 for r in all_results if r["status"] == "SKIP")
    pct     = round(passed / total * 100) if total else 0
    wall    = time.perf_counter() - start

    _banner("OVERALL SUMMARY")
    print(f"  Total   : {total}")
    print(f"  ✅ Pass  : {passed}  ({pct}%)")
    print(f"  ❌ Fail  : {failed}")
    print(f"  ⏭ Skip  : {skipped}")
    print(f"  ⏱ Time  : {wall:.1f}s")

    Path("reports").mkdir(exist_ok=True)
    ts   = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    path = f"reports/pdp_smoke_{ts}.html"
    generate_report(all_results, path)

    print("\n✅ Done.\n")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())

"""
tests/test_04_find_similar_products.py
────────────────────────────────────────────────────────────────────────────
TestLink Suite : Find Similar Products  (id: 458441)
Test Cases     : 4 TCs  →  TC-5942, TC-5943, TC-5944, TC-5945
────────────────────────────────────────────────────────────────────────────
"""
from __future__ import annotations
from playwright.sync_api import Page
from utils.helpers import check, land_on_pdp_via_search
from config import SEARCH_BASE_URL, SEARCH_KEYWORD

SUITE = "Find Similar Products"

SIMILAR_SECTION_SEL = (
    "section:has-text('Find products similar'), "
    "div:has-text('Find products similar'), "
    "[class*='similar'], h2:has-text('similar'), "
    "h3:has-text('similar')"
)
GET_BEST_PRICE_BTN = (
    "button:has-text('Get Best Price'), a:has-text('Get Best Price')"
)
ENQUIRY_FORM_SEL = (
    ".modal:visible, .popup:visible, .enquiry-form:visible, "
    "[class*='enquiry']:visible, [class*='modal']:visible, "
    "div[role='dialog']:visible, #inquiry_form:visible"
)


def _go_to_pdp(page: Page) -> None:
    land_on_pdp_via_search(page, SEARCH_BASE_URL, SEARCH_KEYWORD)


def _scroll_to_similar(page: Page) -> None:
    """Scroll until the 'Find Similar Products' section is in view."""
    section = page.locator(SIMILAR_SECTION_SEL).first
    assert section.count() > 0 or page.locator(
        "text=/similar/i"
    ).count() > 0, "Similar products section not found on this PDP"
    section.scroll_into_view_if_needed()
    page.wait_for_timeout(800)


def run(page: Page) -> list[dict]:
    results: list[dict] = []

    # ── TC-5942 ──────────────────────────────────────────────────────────
    # Verify that similar products related to the product name are displayed
    def _tc5942():
        _go_to_pdp(page)
        _scroll_to_similar(page)
        # At least one product card inside the similar section
        cards = page.locator(
            "a[href*='proddetail']:visible, .similar-product-card:visible"
        ).count()
        assert cards > 0, "No similar product cards visible in the section"

    results.append(check("TC-5942",
        "Verify that similar products related to the product name are displayed",
        SUITE, _tc5942))

    # ── TC-5943 ──────────────────────────────────────────────────────────
    # Verify that clicking on 'Get Best Price' CTA opens the enquiry form
    def _tc5943():
        _go_to_pdp(page)
        _scroll_to_similar(page)
        btn = page.locator(GET_BEST_PRICE_BTN).first
        assert btn.is_visible(), "'Get Best Price' CTA not visible in similar products section"
        btn.click()
        page.wait_for_timeout(1500)
        assert page.locator(ENQUIRY_FORM_SEL).count() > 0, \
            "Enquiry/requirement form did not open after clicking Get Best Price"

    results.append(check("TC-5943",
        "Verify that clicking on 'Get Best Price' CTA opens the enquiry form",
        SUITE, _tc5943))

    # ── TC-5944 ──────────────────────────────────────────────────────────
    # Verify that clicking on the product name redirects to the PDP page
    def _tc5944():
        _go_to_pdp(page)
        _scroll_to_similar(page)
        # Click first product name link in the similar products section
        prod_link = page.locator(
            "a[href*='proddetail']:visible"
        ).first
        assert prod_link.is_visible(), "No product link visible in similar products section"
        prod_link.click()
        page.wait_for_load_state("domcontentloaded", timeout=60_000)
        assert "proddetail" in page.url, \
            f"Did not navigate to a PDP after clicking product name. URL: {page.url}"

    results.append(check("TC-5944",
        "Verify that clicking on the product name redirects to the PDP page",
        SUITE, _tc5944))

    # ── TC-5945 ──────────────────────────────────────────────────────────
    # Verify that clicking on 'View Mobile Number' CTA shows seller mobile number
    def _tc5945():
        _go_to_pdp(page)
        _scroll_to_similar(page)
        view_mobile_btn = page.locator(
            "button:has-text('View Mobile Number'), a:has-text('View Mobile'), "
            "button:has-text('View Mobile'), a:has-text('View Number')"
        ).first
        assert view_mobile_btn.is_visible(), \
            "'View Mobile Number' CTA not visible in similar products section"
        view_mobile_btn.click()
        page.wait_for_timeout(1500)
        # Expect phone number to be revealed or modal shown
        import re
        body = page.inner_text("body")
        has_number = bool(re.search(r"\+91[-\s]?\d{10}|\d{10}", body))
        has_modal  = page.locator(ENQUIRY_FORM_SEL).count() > 0
        assert has_number or has_modal, \
            "Seller mobile number not shown after clicking View Mobile Number"

    results.append(check("TC-5945",
        "Verify that clicking on view mobile number CTA redirects to the enquiry form",
        SUITE, _tc5945))

    return results

"""
tests/test_02_pdp_first_fold.py
────────────────────────────────────────────────────────────────────────────
TestLink Suite : PDP First fold  (id: 371125)
Test Cases     : TC-5548 to TC-5554, TC-5906, TC-5907, TC-5939, TC-5940, TC-5941
────────────────────────────────────────────────────────────────────────────
"""
from __future__ import annotations
import re
from playwright.sync_api import Page
from utils.helpers import check, land_on_pdp_via_search
from config import SEARCH_BASE_URL, SEARCH_KEYWORD

SUITE = "PDP First Fold"

# ── Shared selectors ──────────────────────────────────────────────────────
ENQUIRY_FORM_SEL = (
    ".modal:visible, "
    "#contact_form_wrapper:visible, "
    ".enquiry-form:visible, "
    "[class*='enquiry']:visible, "
    "[class*='modal']:visible, "
    "div[role='dialog']:visible, "
    "#inquiry_form:visible, "
    ".quick-form:visible, "
    ".rqst_frm_wrap:visible"
)
ENQUIRE_NOW_BTN = (
    "button:has-text('Enquire Now'), a:has-text('Enquire Now'), "
    "button:has-text('Enquiry Now'), a:has-text('Enquiry Now'), "
    "button:has-text('Send Enquiry'), a:has-text('Send Enquiry')"
)
SUBMIT_REQ_BTN = (
    "button:has-text('Submit Requirement'), "
    "a:has-text('Submit Requirement'), "
    "input[value*='Submit Requirement']"
)
CONTACT_SUPPLIER_BTN = (
    "button:has-text('Contact Supplier'), a:has-text('Contact Supplier'), "
    "button:has-text('Contact supplier'), a:has-text('Contact supplier'), "
    "button:has-text('Contact Seller'), a:has-text('Contact Seller')"
)
CALL_NOW_BTN = (
    "button:has-text('Call Now'), a:has-text('Call Now'), "
    "button:has-text('Call'), a:has-text('Call')"
)


def _go_to_pdp(page: Page) -> None:
    """
    Navigate to PDP via search exactly as per TestLink steps:
    1. go to dir.indiamart.com
    2. Click search bar → enter 'tmt bar'
    3. Click first search suggestion
    4. Click first product name under search results
    """
    land_on_pdp_via_search(page, SEARCH_BASE_URL, SEARCH_KEYWORD)
    # Wait for the PDP first-fold to fully render
    page.wait_for_selector("h1", timeout=15_000)


def _form_appeared(page: Page) -> bool:
    """Return True if any enquiry/modal form is visible."""
    page.wait_for_timeout(1500)
    return page.locator(ENQUIRY_FORM_SEL).count() > 0


def run(page: Page) -> list[dict]:
    results: list[dict] = []

    # ── TC-5548 ───────────────────────────────────────────────────────────
    # Steps:
    #   1–4. Land on PDP via search
    #   2. Click on product image
    #   3. Click on the "Enquire Now" CTA
    # Expected: Image enquiry form should be displayed
    def _tc5548():
        _go_to_pdp(page)
        page.locator(
            "img[src*='imimg.com'], .product-image img, #imgMain, .main-img img"
        ).first.click()
        page.wait_for_timeout(1000)
        # Enquire Now should now appear OR form already open
        enquire_btn = page.locator(ENQUIRE_NOW_BTN).first
        if enquire_btn.is_visible():
            enquire_btn.click()
            page.wait_for_timeout(1000)
        assert _form_appeared(page) or page.locator(ENQUIRE_NOW_BTN).count() > 0, \
            "Image enquiry form / Enquire Now CTA not shown after image click"

    results.append(check("TC-5548",
        "Verify that image enquiry form should opens, if user click on product image",
        SUITE, _tc5548))

    # ── TC-5549 ───────────────────────────────────────────────────────────
    # Steps:
    #   1–4. Land on PDP via search
    #   2. Click 'Enquiry Now' CTA → enter mobile 1212121212 → Submit
    #   3. Enter 1 in quantity → click Next on every fold
    # Expected: "Thank You" screen displayed at last
    def _tc5549():
        _go_to_pdp(page)
        btn = page.locator(ENQUIRE_NOW_BTN).first
        btn.wait_for(state="visible", timeout=10_000)
        btn.click()
        page.wait_for_timeout(1000)

        # Enter mobile number
        mobile = page.locator(
            "input[type='tel'], input[placeholder*='mobile'], "
            "input[placeholder*='Mobile'], input[name*='mobile'], "
            "input[maxlength='10']"
        ).first
        mobile.wait_for(state="visible", timeout=8_000)
        mobile.fill("1212121212")

        # Click Submit
        page.locator(
            "button[type='submit'], input[type='submit'], "
            "button:has-text('Submit'), button:has-text('Proceed')"
        ).first.click()
        page.wait_for_timeout(2000)

        # Should show quantity form or next step
        assert (
            page.locator(
                "input[placeholder*='quantity'], input[name*='qty'], "
                "button:has-text('Next'), text=/quantity/i, text=/thank you/i"
            ).count() > 0
        ), "Quantity form / Thank You screen not shown after mobile submit"

    results.append(check("TC-5549",
        "Verify that user able to submit the requirement on clicking the enquiry now CTA",
        SUITE, _tc5549))

    # ── TC-5550 ───────────────────────────────────────────────────────────
    # Steps:
    #   1–4. Land on PDP via search
    #   3. Click on submit requirement CTA
    # Expected: Enquiry form should open
    def _tc5550():
        _go_to_pdp(page)
        btn = page.locator(SUBMIT_REQ_BTN).first
        btn.wait_for(state="visible", timeout=10_000)
        btn.click()
        assert _form_appeared(page), \
            "Enquiry form did not open after clicking Submit Requirement"

    results.append(check("TC-5550",
        "Verify that Enquiry form should opens after clicking on the submit requirement CTA",
        SUITE, _tc5550))

    # ── TC-5551 ───────────────────────────────────────────────────────────
    # Steps:
    #   1–4. Land on PDP via search
    #   2. Click on Company name under company details
    # Expected: User should be redirected to company page
    def _tc5551():
        _go_to_pdp(page)
        company_link = page.locator(
            ".company-name a, "
            "a.seller-name, "
            "h2.seller-name a, "
            ".cmp_name a, "
            "a[href*='indiamart.com/']:not([href*='proddetail']):not([href*='dir.'])"
        ).first
        company_link.wait_for(state="visible", timeout=10_000)
        href = company_link.get_attribute("href") or ""
        company_link.click()
        page.wait_for_load_state("domcontentloaded", timeout=60_000)
        assert "proddetail" not in page.url and "indiamart.com" in page.url, \
            f"Not on company page. URL: {page.url}"

    results.append(check("TC-5551",
        "Verify that user is redirected to company page after clicking on company name",
        SUITE, _tc5551))

    # ── TC-5552 ───────────────────────────────────────────────────────────
    # Steps:
    #   1–4. Land on PDP via search
    #   2. Click on Review count under company details
    # Expected: User should be redirected to rating and review section
    def _tc5552():
        _go_to_pdp(page)
        review_link = page.locator(
            "a[href*='#review'], a[href*='#rating'], "
            ".review-count a, a:has-text('Review'), "
            "span.rating a, .ratng_cnt a"
        ).first
        review_link.wait_for(state="visible", timeout=10_000)
        review_link.click()
        page.wait_for_timeout(1500)
        assert (
            "#review" in page.url or "#rating" in page.url
            or page.locator(
                "#review, #rating, [id*='review'], "
                "h2:has-text('Rating'), h3:has-text('Review')"
            ).count() > 0
        ), "Rating/Review section not in view after clicking review count"

    results.append(check("TC-5552",
        "Verify that Review count is redirected to the rating and review section of pdp page",
        SUITE, _tc5552))

    # ── TC-5553 ───────────────────────────────────────────────────────────
    # Steps:
    #   1–4. Land on PDP via search
    #   2. Observe PNS number in first fold (company) and second fold (seller details)
    # Expected:
    #   - Without extension: number visible directly
    #   - With extension: Call Now / View Mobile Number shown
    def _tc5553():
        _go_to_pdp(page)
        body = page.inner_text("body")
        has_direct_number = bool(re.search(r"\+91[-\s]?\d{10}|\b\d{10}\b", body))
        has_call_cta      = page.locator(CALL_NOW_BTN).count() > 0
        has_view_mobile   = page.locator(
            "button:has-text('View Mobile'), a:has-text('View Mobile')"
        ).count() > 0
        assert has_direct_number or has_call_cta or has_view_mobile, \
            "Neither PNS number nor Call Now / View Mobile Number CTA found"

    results.append(check("TC-5553",
        "Verify that Seller PNS number should display without clicking on Call Now CTA",
        SUITE, _tc5553))

    # ── TC-5554 ───────────────────────────────────────────────────────────
    # Steps:
    #   1–4. Land on PDP via search
    #   2. Click on Contact Supplier CTA under company details
    # Expected: Enquiry form should open
    def _tc5554():
        _go_to_pdp(page)
        btn = page.locator(CONTACT_SUPPLIER_BTN).first
        btn.wait_for(state="visible", timeout=10_000)
        btn.click()
        assert _form_appeared(page), \
            "Enquiry form did not open after clicking Contact Supplier"

    results.append(check("TC-5554",
        "Verify that enquiry form should opens, if user clicks on Contact supplier CTA",
        SUITE, _tc5554))

    # ── TC-5906 ───────────────────────────────────────────────────────────
    # Steps:
    #   1–4. Land on PDP via search
    #   2. Click on Call Now CTA → enter mobile number if prompted
    # Expected: User should receive call from seller
    # (Automated: verifies CTA is present and interaction is triggered)
    def _tc5906():
        _go_to_pdp(page)
        btn = page.locator(CALL_NOW_BTN).first
        btn.wait_for(state="visible", timeout=10_000)
        assert btn.is_visible(), "Call Now CTA not visible in first fold"
        btn.click()
        page.wait_for_timeout(1500)
        assert (
            _form_appeared(page)
            or page.locator("a[href*='tel:']").count() > 0
            or page.locator(
                "input[type='tel'], input[placeholder*='mobile']"
            ).count() > 0
        ), "No modal or tel: link appeared after clicking Call Now"

    results.append(check("TC-5906",
        "Verify that user can receive the call from the seller on clicking 'Call Now' CTA",
        SUITE, _tc5906))

    # ── TC-5907 ───────────────────────────────────────────────────────────
    # Steps:
    #   1–4. Land on PDP via search
    #   2. Click on Contact Supplier CTA
    # Expected: Enquiry form should be displayed
    def _tc5907():
        _go_to_pdp(page)
        btn = page.locator(CONTACT_SUPPLIER_BTN).first
        btn.wait_for(state="visible", timeout=10_000)
        btn.click()
        assert _form_appeared(page), \
            "Enquiry form not displayed after clicking Contact Supplier"

    results.append(check("TC-5907",
        "Verify that Clicking on 'Contact Supplier' CTA displays the enquiry form",
        SUITE, _tc5907))

    # ── TC-5939 ───────────────────────────────────────────────────────────
    # Steps:
    #   1–4. Land on PDP via search
    #   2. Click on the PDF brochure (near image / price tag)
    # Expected: Quick requirement form should open
    def _tc5939():
        _go_to_pdp(page)
        pdf_link = page.locator(
            "a[href*='.pdf'], a:has-text('Brochure'), "
            "a:has-text('View Now'), img[src*='pdf']"
        ).first
        if not pdf_link.is_visible():
            raise AssertionError(
                "No brochure/PDF link found on this PDP — "
                "element is optional and absent on this product"
            )
        pdf_link.click()
        page.wait_for_timeout(1500)
        assert _form_appeared(page), \
            "Quick requirement form did not open after clicking brochure PDF"

    results.append(check("TC-5939",
        "Verify that clicking on the brochure PDF(if applicable) opens the quick requirement form",
        SUITE, _tc5939))

    # ── TC-5940 ───────────────────────────────────────────────────────────
    # Steps:
    #   1–4. Land on PDP via search
    #   2. Click on the video icon in the image section
    # Expected: Enquiry form should open
    def _tc5940():
        _go_to_pdp(page)
        video_icon = page.locator(
            ".video-icon, [class*='video-btn'], "
            "button[class*='video'], a[class*='video'], "
            ".play-btn, .play-button, img[alt*='video']"
        ).first
        if not video_icon.is_visible():
            raise AssertionError(
                "No video icon found on this PDP — "
                "element is optional and absent on this product"
            )
        video_icon.click()
        page.wait_for_timeout(1500)
        assert _form_appeared(page), \
            "Enquiry form did not open after clicking video icon"

    results.append(check("TC-5940",
        "Verify that clicking on the video icon opens the enquiry form",
        SUITE, _tc5940))

    # ── TC-5941 ───────────────────────────────────────────────────────────
    # Steps:
    #   1–4. Land on PDP via search
    #   2. Click on the hindi product name in product description
    # Expected: User should land on the hindi PDP page
    def _tc5941():
        _go_to_pdp(page)
        hindi_link = page.locator(
            "a[href*='hindi.indiamart.com'], "
            "a[hreflang='hi'], "
            "a:has-text('View in Hindi'), "
            "a[href*='/hi/']"
        ).first
        hindi_link.wait_for(state="visible", timeout=10_000)
        hindi_link.click()
        page.wait_for_load_state("domcontentloaded", timeout=60_000)
        assert (
            "hindi.indiamart.com" in page.url
            or "/hi/" in page.url
            or "lang=hi" in page.url
        ), f"Did not navigate to Hindi PDP. URL: {page.url}"

    results.append(check("TC-5941",
        "Verify that clicking on 'View in hindi' redirects the user to hindi PDP page",
        SUITE, _tc5941))

    return results

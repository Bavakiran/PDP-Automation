"""
tests/test_09_about_the_company.py
────────────────────────────────────────────────────────────────────────────
TestLink Suite : About the Company  (id: 458446)
Test Cases     : 2 TCs  →  TC-5955, TC-5956
────────────────────────────────────────────────────────────────────────────
"""
from __future__ import annotations
import re
from playwright.sync_api import Page
from utils.helpers import check, land_on_pdp_via_search
from config import SEARCH_BASE_URL, SEARCH_KEYWORD

SUITE = "About the Company"

PRODUCT_DETAILS_TAB = (
    "button:has-text('Product Details'), a:has-text('Product Details'), "
    "li:has-text('Product Details')"
)
COMPANY_DETAILS_TAB = (
    "button:has-text('Company Details'), a:has-text('Company Details'), "
    "li:has-text('Company Details'), span:has-text('Company Details')"
)
RATINGS_SECTION_SEL = (
    "#review, #rating, [id*='review'], [id*='rating'], "
    "h2:has-text('Rating'), h3:has-text('Rating'), "
    "section:has-text('Rating'), div:has-text('Reviews')"
)


def _go_to_pdp(page: Page) -> None:
    land_on_pdp_via_search(page, SEARCH_BASE_URL, SEARCH_KEYWORD)


def run(page: Page) -> list[dict]:
    results: list[dict] = []

    # ── TC-5955 ──────────────────────────────────────────────────────────
    # Verify that company details are displayed
    # Step 1: Shipping info under product details
    # Step 2: Toggle to Company Details → GST/IEC masked
    def _tc5955():
        _go_to_pdp(page)
        # Scroll to product details section
        page.evaluate("window.scrollTo(0, document.body.scrollHeight * 0.5)")
        page.wait_for_timeout(600)

        # Check shipping info present
        body = page.inner_text("body")
        assert re.search(r"shipping|dispatch|delivery", body, re.I), \
            "Shipping/dispatch/delivery info not found in product details section"

        # Toggle to Company Details tab (if tabbed layout)
        company_tab = page.locator(COMPANY_DETAILS_TAB).first
        if company_tab.count() > 0:
            company_tab.click()
            page.wait_for_timeout(800)

        body = page.inner_text("body")
        # GST should be present (masked)
        assert re.search(r"GST", body, re.I), "GST detail not found in company section"
        # IEC masked or present
        assert re.search(r"IEC|import export|GST|\d{2}[A-Z]{5}\d{4}", body, re.I), \
            "IEC/company identifier not found"

    results.append(check("TC-5955",
        "Verify that company details are displayed",
        SUITE, _tc5955))

    # ── TC-5956 ──────────────────────────────────────────────────────────
    # Verify that ratings and reviews are displayed
    def _tc5956():
        _go_to_pdp(page)

        # Toggle to company details tab if present
        company_tab = page.locator(COMPANY_DETAILS_TAB).first
        if company_tab.count() > 0:
            company_tab.click()
            page.wait_for_timeout(600)

        # Scroll down to rating section
        page.evaluate("window.scrollTo(0, document.body.scrollHeight)")
        page.wait_for_timeout(800)

        assert (
            page.locator(RATINGS_SECTION_SEL).count() > 0
            or re.search(r"\d\.\d.*rating|rating.*\d\.\d|reviews?",
                         page.inner_text("body"), re.I)
        ), "Ratings & Reviews section not found after company details"

    results.append(check("TC-5956",
        "Verify that ratings and reviews are displayed",
        SUITE, _tc5956))

    return results

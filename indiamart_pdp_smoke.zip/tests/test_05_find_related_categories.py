"""
tests/test_05_find_related_categories.py
────────────────────────────────────────────────────────────────────────────
TestLink Suite : Find related categories  (id: 458442)
Test Cases     : 3 TCs  →  TC-5946, TC-5947, TC-5948
────────────────────────────────────────────────────────────────────────────
"""
from __future__ import annotations
from playwright.sync_api import Page
from utils.helpers import check, land_on_pdp_via_search
from config import SEARCH_BASE_URL, SEARCH_KEYWORD

SUITE = "Find Related Categories"

RELATED_CAT_SEL = (
    "section:has-text('Related'), div:has-text('Related Categor'), "
    "[class*='related-cat'], h2:has-text('Related'), h3:has-text('Related')"
)
ENQUIRY_FORM_SEL = (
    ".modal:visible, .popup:visible, .enquiry-form:visible, "
    "[class*='enquiry']:visible, [class*='modal']:visible, "
    "div[role='dialog']:visible, #inquiry_form:visible"
)
GET_QUOTES_BTN = (
    "button:has-text('Get Quotes'), a:has-text('Get Quotes')"
)


def _go_to_pdp(page: Page) -> None:
    land_on_pdp_via_search(page, SEARCH_BASE_URL, SEARCH_KEYWORD)


def _scroll_to_related_cats(page: Page) -> None:
    page.evaluate("window.scrollTo(0, document.body.scrollHeight * 0.5)")
    page.wait_for_timeout(800)
    section = page.locator(RELATED_CAT_SEL).first
    if section.count() > 0:
        section.scroll_into_view_if_needed()
    page.wait_for_timeout(600)


def run(page: Page) -> list[dict]:
    results: list[dict] = []

    # ── TC-5946 ──────────────────────────────────────────────────────────
    # Verify that related categories related to product are displayed
    def _tc5946():
        _go_to_pdp(page)
        _scroll_to_related_cats(page)
        assert page.locator(RELATED_CAT_SEL).count() > 0 or \
               page.locator("text=/related categor/i").count() > 0, \
            "Related categories section not found on this PDP"
        # At least one category tile visible
        tiles = page.locator(
            "a[href*='impcat'], a[href*='indianexporters'], "
            "[class*='cat-tile'], [class*='category-tile']"
        ).count()
        assert tiles > 0, "No related category tiles found"

    results.append(check("TC-5946",
        "Verify that related categories related to product are displayed",
        SUITE, _tc5946))

    # ── TC-5947 ──────────────────────────────────────────────────────────
    # Verify that clicking on the category tiles redirects to MCAT/Search page
    def _tc5947():
        _go_to_pdp(page)
        _scroll_to_related_cats(page)
        tile = page.locator(
            "a[href*='impcat'], a[href*='indianexporters'], "
            "[class*='cat-tile'] a, [class*='category-tile'] a"
        ).first
        assert tile.is_visible(), "No category tile link visible"
        tile.click()
        page.wait_for_load_state("domcontentloaded", timeout=60_000)
        assert (
            "indiamart.com/impcat" in page.url
            or "dir.indiamart.com" in page.url
            or "indiamart.com/indianexporters" in page.url
            or "search" in page.url.lower()
        ), f"Category tile did not redirect to MCAT/Search. URL: {page.url}"

    results.append(check("TC-5947",
        "Verify that clicking on the category tiles redirects to the MCAT/Search category page",
        SUITE, _tc5947))

    # ── TC-5948 ──────────────────────────────────────────────────────────
    # Verify that clicking on 'Get Quotes' opens the BL form
    # (Display ID ≠ 2 → BL form; Display ID = 2 → no Get Quotes CTA)
    def _tc5948():
        _go_to_pdp(page)
        _scroll_to_related_cats(page)
        btn = page.locator(GET_QUOTES_BTN).first
        if btn.count() == 0:
            # Display ID = 2 case: no CTA expected → PASS
            return
        assert btn.is_visible(), "'Get Quotes' CTA not visible"
        btn.click()
        page.wait_for_timeout(1500)
        assert page.locator(ENQUIRY_FORM_SEL).count() > 0 or \
               page.locator("text=/buy lead/i, text=/requirement/i").count() > 0, \
            "BL form did not open after clicking Get Quotes"

    results.append(check("TC-5948",
        "Verify that clicking on 'Get Quotes' opens the BL form",
        SUITE, _tc5948))

    return results

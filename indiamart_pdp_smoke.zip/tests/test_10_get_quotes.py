"""
tests/test_10_get_quotes.py
────────────────────────────────────────────────────────────────────────────
TestLink Suite : Get Quotes from verified suppliers  (id: 458447)
Test Cases     : 2 TCs  →  TC-5957, TC-5958
────────────────────────────────────────────────────────────────────────────
"""
from __future__ import annotations
from playwright.sync_api import Page
from utils.helpers import check, land_on_pdp_via_search
from config import SEARCH_BASE_URL, SEARCH_KEYWORD

SUITE = "Get Quotes from Verified Suppliers"

# Inline BL form selectors
BL_FORM_SEL = (
    "section:has-text('Tell us what you need'), "
    "div:has-text('help you get quotes'), "
    "[class*='bl-form'], [class*='buy-lead'], "
    "form:has(input[placeholder*='product'])"
)
PRODUCT_PREFILL_INPUT = (
    "input[value][placeholder*='product'], "
    "input[value][placeholder*='Product'], "
    "textarea[value][placeholder*='product'], "
    "input.product-name-input"
)
SUBMIT_REQ_BTN = (
    "button:has-text('Submit Requirement'), a:has-text('Submit Requirement'), "
    "input[value*='Submit Requirement'], button[type='submit']"
)
BL_MODAL_SEL = (
    ".modal:visible, .popup:visible, div[role='dialog']:visible, "
    "[class*='bl-modal']:visible, [class*='buy-lead-form']:visible"
)


def _go_to_pdp(page: Page) -> None:
    land_on_pdp_via_search(page, SEARCH_BASE_URL, SEARCH_KEYWORD)


def _scroll_to_bl_form(page: Page) -> None:
    """Scroll to the inline BL / 'Tell us what you need' form."""
    page.evaluate("window.scrollTo(0, document.body.scrollHeight * 0.75)")
    page.wait_for_timeout(600)
    bl = page.locator(BL_FORM_SEL).first
    if bl.count() > 0:
        bl.scroll_into_view_if_needed()
    page.wait_for_timeout(500)


def run(page: Page) -> list[dict]:
    results: list[dict] = []

    # ── TC-5957 ──────────────────────────────────────────────────────────
    # Verify that product name is prefilled in the text box
    def _tc5957():
        _go_to_pdp(page)
        product_name = page.locator("h1").first.inner_text().strip()
        _scroll_to_bl_form(page)

        assert page.locator(BL_FORM_SEL).count() > 0, \
            "'Tell us what you need' / inline BL form not found on this PDP"

        # Check prefill – either input value or textarea contains product name words
        prefill_input = page.locator(PRODUCT_PREFILL_INPUT).first
        if prefill_input.count() > 0:
            val = prefill_input.input_value()
            assert val.strip(), "Product name input in BL form is empty (not prefilled)"
        else:
            # Fallback: product name text visible inside the BL form area
            form_text = page.locator(BL_FORM_SEL).first.inner_text()
            first_word = product_name.split()[0] if product_name else ""
            assert first_word and first_word.lower() in form_text.lower(), \
                f"Product name '{first_word}' not prefilled in BL form"

    results.append(check("TC-5957",
        "Verify that product name are prefilled in the text box",
        SUITE, _tc5957))

    # ── TC-5958 ──────────────────────────────────────────────────────────
    # Verify that clicking on 'Submit Requirement' CTA opens the BL forms
    def _tc5958():
        _go_to_pdp(page)
        _scroll_to_bl_form(page)

        assert page.locator(BL_FORM_SEL).count() > 0, \
            "Inline BL form section not found on this PDP"

        btn = page.locator(SUBMIT_REQ_BTN).first
        assert btn.is_visible(), "'Submit Requirement' CTA not visible in BL form"
        btn.click()
        page.wait_for_timeout(2000)
        assert page.locator(BL_MODAL_SEL).count() > 0 or \
               page.locator("text=/tell us/i, text=/requirement/i").count() > 0, \
            "BL form modal did not open after clicking Submit Requirement"

    results.append(check("TC-5958",
        "Verify that clicking on 'Submit Requirement' CTA opens the BL forms",
        SUITE, _tc5958))

    return results

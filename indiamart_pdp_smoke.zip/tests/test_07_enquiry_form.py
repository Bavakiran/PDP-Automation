"""
tests/test_07_enquiry_form.py
────────────────────────────────────────────────────────────────────────────
TestLink Suite : Enquiry form  (id: 458444)
Test Cases     : 2 TCs  →  TC-5951, TC-5952
────────────────────────────────────────────────────────────────────────────
"""
from __future__ import annotations
from playwright.sync_api import Page
from utils.helpers import check, land_on_pdp_via_search
from config import SEARCH_BASE_URL, SEARCH_KEYWORD

SUITE = "Enquiry Form"

ENQUIRY_FORM_SEL = (
    ".modal:visible, .popup:visible, .enquiry-form:visible, "
    "[class*='enquiry']:visible, [class*='modal']:visible, "
    "div[role='dialog']:visible, #inquiry_form:visible"
)
SUBMIT_REQ_BTN = (
    "button:has-text('Submit Requirement'), a:has-text('Submit Requirement'), "
    "button:has-text('Submit'), input[value*='Submit Requirement']"
)
CHAT_NOW_BTN = (
    "button:has-text('Chat Now'), a:has-text('Chat Now'), "
    "button:has-text('Chat'), a:has-text('Chat')"
)


def _go_to_pdp(page: Page) -> None:
    land_on_pdp_via_search(page, SEARCH_BASE_URL, SEARCH_KEYWORD)


def run(page: Page) -> list[dict]:
    results: list[dict] = []

    # ── TC-5951 ──────────────────────────────────────────────────────────
    # Verify that clicking on the 'Submit Requirement' CTA opens the enquiry form
    def _tc5951():
        _go_to_pdp(page)
        # Look for Submit Requirement in the right panel / seller details
        btn = page.locator(SUBMIT_REQ_BTN).first
        assert btn.is_visible(), "'Submit Requirement' CTA not visible in seller panel"
        btn.click()
        page.wait_for_timeout(1500)
        assert page.locator(ENQUIRY_FORM_SEL).count() > 0, \
            "Enquiry form did not open after clicking Submit Requirement"

    results.append(check("TC-5951",
        "Verify that clicking on the 'Submit Requirement' CTA opens the enquiry form",
        SUITE, _tc5951))

    # ── TC-5952 ──────────────────────────────────────────────────────────
    # Verify that clicking on 'Chat Now' CTA opens the chat enquiry form
    def _tc5952():
        _go_to_pdp(page)
        btn = page.locator(CHAT_NOW_BTN).first
        assert btn.is_visible(), "'Chat Now' CTA not visible on this PDP"
        btn.click()
        page.wait_for_timeout(1500)
        # Chat form / chat widget / enquiry modal should appear
        assert (
            page.locator(ENQUIRY_FORM_SEL).count() > 0
            or page.locator("[class*='chat']:visible").count() > 0
        ), "Chat enquiry form did not open after clicking Chat Now"

    results.append(check("TC-5952",
        "Verify that clicking on 'Chat Now' CTA, opens the chat enquiry form",
        SUITE, _tc5952))

    return results

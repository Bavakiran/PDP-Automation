"""
tests/test_11_header_footer.py
────────────────────────────────────────────────────────────────────────────
TestLink Suite : Header/footer  (id: 458448)
Test Cases     : 2 TCs  →  TC-5959, TC-5960
────────────────────────────────────────────────────────────────────────────
"""
from __future__ import annotations
from playwright.sync_api import Page, expect
from utils.helpers import check, land_on_pdp_via_search
from config import SEARCH_BASE_URL, SEARCH_KEYWORD, TIMEOUT

SUITE = "Header / Footer"

LOGO_SEL          = "a.logo, header img[alt*='IndiaMART'], a[href*='indiamart.com'] img"
SEARCH_BAR_SEL    = "input#search_bar_input, input[name='q'], input[type='search'], input[placeholder*='Search']"
SEARCH_BTN_SEL    = "button[type='submit'], button:has-text('Search'), .search-btn"
FOOTER_LINK_SEL   = "footer a[href]"


def _go_to_pdp(page: Page) -> None:
    land_on_pdp_via_search(page, SEARCH_BASE_URL, SEARCH_KEYWORD)


def run(page: Page) -> list[dict]:
    results: list[dict] = []

    # ── TC-5959 ──────────────────────────────────────────────────────────
    # Verify that redirection of header CTAs
    # Step 1: IndiaMart logo → homepage
    # Step 2: Country dropdown + city search → search page
    # Step 3: Search bar with product → search results
    # Step 4: Exporters/Sell/Help/Messages/Sign In → respective pages
    def _tc5959():
        _go_to_pdp(page)

        # ── Step 1: Logo → Homepage ──────────────────────────────────────
        logo = page.locator(LOGO_SEL).first
        assert logo.is_visible(), "IndiaMart logo not visible in header"
        logo.click()
        page.wait_for_load_state("domcontentloaded", timeout=60_000)
        assert "indiamart.com" in page.url, \
            f"Logo click did not navigate to IndiaMart. URL: {page.url}"

        # Navigate back to PDP for next steps
        _go_to_pdp(page)

        # ── Step 2: Search bar → search page ─────────────────────────────
        search_input = page.locator(SEARCH_BAR_SEL).first
        assert search_input.is_visible(), "Header search bar not visible"
        search_input.fill("steel pipes")
        page.keyboard.press("Enter")
        page.wait_for_load_state("domcontentloaded", timeout=60_000)
        assert (
            "search" in page.url.lower()
            or "dir.indiamart.com" in page.url
            or "indiamart.com" in page.url
        ), f"Search did not redirect to search page. URL: {page.url}"

        # Navigate back to PDP
        _go_to_pdp(page)

        # ── Step 3: Header nav links (Sell/Exporters/Sign In) ─────────────
        nav_links = page.locator(
            "header a:has-text('Sell'), header a:has-text('Sign In'), "
            "header a:has-text('Exporters'), header a:has-text('Help')"
        ).all()
        assert len(nav_links) > 0, "No nav links (Sell/Sign In/Exporters/Help) found in header"
        # Verify each has a valid href
        for lnk in nav_links[:4]:
            href = lnk.get_attribute("href") or ""
            assert href, f"Header nav link '{lnk.inner_text()}' has no href"

    results.append(check("TC-5959",
        "Verify that redirection of header CTAs",
        SUITE, _tc5959))

    # ── TC-5960 ──────────────────────────────────────────────────────────
    # Verify that redirect of footer CTAs
    def _tc5960():
        _go_to_pdp(page)

        # Scroll to footer
        page.evaluate("window.scrollTo(0, document.body.scrollHeight)")
        page.wait_for_timeout(800)

        footer_links = page.locator(FOOTER_LINK_SEL).all()
        assert len(footer_links) > 0, "No links found in footer"

        broken = []
        for lnk in footer_links[:10]:   # test first 10 footer links
            href = lnk.get_attribute("href") or ""
            if not href or href.strip() in ("#", "javascript:void(0)", ""):
                broken.append(lnk.inner_text().strip()[:40])

        assert not broken, \
            f"{len(broken)} footer link(s) have empty/invalid href: {broken[:5]}"

    results.append(check("TC-5960",
        "Verify that redirect of footer CTAs",
        SUITE, _tc5960))

    return results

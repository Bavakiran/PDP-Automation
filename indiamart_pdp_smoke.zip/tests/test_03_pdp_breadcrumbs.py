"""
tests/test_03_pdp_breadcrumbs.py
────────────────────────────────────────────────────────────────────────────
TestLink Suite : PDP breadcrumbs  (id: 381112)
Test Cases     : 3 TCs  →  TC-5628, TC-5629, TC-5630
Base PDP URL   : https://www.indiamart.com/proddetail/tata-tiscon-10mm-tmt-rebars-2855886579312.html
────────────────────────────────────────────────────────────────────────────
"""
from __future__ import annotations
from playwright.sync_api import Page, expect
from utils.helpers import check, navigate
from config import BREADCRUMB_PDP_URL, TIMEOUT

SUITE = "PDP Breadcrumbs"

BREADCRUMB_SEL = (
    "nav.breadcrumb a, ol.breadcrumb a, "
    ".breadcrumbs a, [class*='breadcrumb'] a, "
    "ul.breadcrumb li a"
)


def _load_pdp(page: Page) -> None:
    status = navigate(page, BREADCRUMB_PDP_URL)
    assert status == 200, f"PDP returned HTTP {status}"
    assert "proddetail" in page.url, f"Not on PDP. URL: {page.url}"


def run(page: Page) -> list[dict]:
    results: list[dict] = []

    # ── TC-5628 ──────────────────────────────────────────────────────────
    # Verify that Indiamart link is redirected to the dir.indiamart.com
    def _tc5628():
        _load_pdp(page)
        breadcrumbs = page.locator(BREADCRUMB_SEL).all()
        assert breadcrumbs, "No breadcrumb links found on the PDP"
        # First breadcrumb = IndiaMart home
        first_bc = breadcrumbs[0]
        first_bc.click()
        page.wait_for_load_state("domcontentloaded", timeout=60_000)
        assert (
            "dir.indiamart.com" in page.url
            or "indiamart.com" in page.url
        ), f"First breadcrumb did not go to IndiaMart. URL: {page.url}"

    results.append(check("TC-5628",
        "Verify that Indiamart link is redirected to the dir.indiamart.com",
        SUITE, _tc5628))

    # ── TC-5629 ──────────────────────────────────────────────────────────
    # Verify that second link under breadcrumbs redirected to subcategories page
    def _tc5629():
        _load_pdp(page)
        breadcrumbs = page.locator(BREADCRUMB_SEL).all()
        assert len(breadcrumbs) >= 2, \
            f"Expected ≥2 breadcrumbs, found {len(breadcrumbs)}"
        second_bc = breadcrumbs[1]
        second_bc.click()
        page.wait_for_load_state("domcontentloaded", timeout=60_000)
        # Expect dir.indiamart.com category/subcategory page
        assert (
            "dir.indiamart.com" in page.url
            or "indiamart.com/indianexporters" in page.url
            or "indiamart.com/impcat" in page.url
        ), f"Second breadcrumb did not reach subcategory page. URL: {page.url}"

    results.append(check("TC-5629",
        "Verify that second link under breadcrumbs redirected to the subcategories page",
        SUITE, _tc5629))

    # ── TC-5630 ──────────────────────────────────────────────────────────
    # Verify that third link under breadcrumbs should redirected to the mcat page
    def _tc5630():
        _load_pdp(page)
        breadcrumbs = page.locator(BREADCRUMB_SEL).all()
        assert len(breadcrumbs) >= 3, \
            f"Expected ≥3 breadcrumbs, found {len(breadcrumbs)}"
        third_bc = breadcrumbs[2]
        third_bc.click()
        page.wait_for_load_state("domcontentloaded", timeout=60_000)
        # Expect an mcat or category page
        assert (
            "indiamart.com/impcat" in page.url
            or "dir.indiamart.com" in page.url
            or "indiamart.com/indianexporters" in page.url
        ), f"Third breadcrumb did not reach mcat page. URL: {page.url}"

    results.append(check("TC-5630",
        "Verify that third link under breadcrumbs should redirected to the mcat page",
        SUITE, _tc5630))

    return results

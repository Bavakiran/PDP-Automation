"""
tests/test_01_pdp_landings.py
────────────────────────────────────────────────────────────────────────────
TestLink Suite : PDP Landings  (id: 370947)
Test Cases     : TC-5543, TC-5546, TC-5547, TC-5905, TC-5989
────────────────────────────────────────────────────────────────────────────
"""
from __future__ import annotations
from playwright.sync_api import Page
from utils.helpers import check, navigate, land_on_pdp_via_search
from config import SEARCH_BASE_URL, SEARCH_KEYWORD, GOOGLE_PDP_URL

SUITE = "PDP Landings"


def run(page: Page) -> list[dict]:
    results: list[dict] = []

    # ── TC-5543 ───────────────────────────────────────────────────────────
    # Steps:
    #   1. go to dir.indiamart.com
    #   2. Click on the search bar and enter tmt bar
    #   3. Click on first search suggestion
    #   4. Click on first product name under search results
    # Expected: User should land on the PDP page
    def _tc5543():
        land_on_pdp_via_search(page, SEARCH_BASE_URL, SEARCH_KEYWORD)
        assert "proddetail" in page.url, \
            f"Expected PDP URL containing 'proddetail'. Got: {page.url}"

    results.append(check("TC-5543",
        "Verify that user able to land on PDP page through search page",
        SUITE, _tc5543))

    # ── TC-5546 ───────────────────────────────────────────────────────────
    # Steps:
    #   1. go to dir.indiamart.com
    #   2. Scroll down to Drugs & Pharmaceuticals category
    #   3. Click on Cough Syrup sub-category under Common Disease Medicines
    #   4. Click on first product name under Mcat page
    # Expected: User should land on PDP page
    def _tc5546():
        page.goto("https://dir.indiamart.com/industry/drugs-medicines.html",
                  wait_until="domcontentloaded", timeout=60_000)

        # Click Cough Syrup link
        cough_link = page.locator(
            "a[href*='cough-syrup'], a:has-text('Cough Syrup')"
        ).first
        cough_link.wait_for(state="visible", timeout=15_000)
        cough_link.click()
        page.wait_for_load_state("domcontentloaded", timeout=60_000)

        # Click first product name on Mcat page
        first_product = page.locator("a[href*='proddetail']").first
        first_product.wait_for(state="visible", timeout=15_000)
        first_product.scroll_into_view_if_needed()
        first_product.click()
        page.wait_for_load_state("domcontentloaded", timeout=60_000)

        assert "proddetail" in page.url, \
            f"Expected PDP URL. Got: {page.url}"

    results.append(check("TC-5546",
        "Verify that user able to land on PDP page through Mcat Page",
        SUITE, _tc5546))

    # ── TC-5547 ───────────────────────────────────────────────────────────
    # Steps:
    #   1. go to dir.indiamart.com
    #   2. Click on the search bar and enter designer lehenga
    #   3. Click on first search suggestion
    #   4. Click on the company name in the first product card (opens new tab)
    #   5. Click on first product name in that company page
    # Expected: User should land on the PDP page
    def _tc5547():
        land_on_pdp_via_search(page, SEARCH_BASE_URL, "designer lehenga")

        # Go back to search results
        page.go_back(wait_until="domcontentloaded", timeout=60_000)

        # Click company name on first product card
        company_link = page.locator(
            ".company-name a, "
            "a[href*='indiamart.com/']:not([href*='proddetail']):not([href*='dir.']), "
            "h3.seller-name a, span.company-name a"
        ).first
        company_link.wait_for(state="visible", timeout=15_000)

        # Handle new tab
        with page.context.expect_page() as new_page_info:
            company_link.click()
        company_page = new_page_info.value
        company_page.wait_for_load_state("domcontentloaded", timeout=60_000)

        # Click first product on company page
        prod = company_page.locator("a[href*='proddetail']").first
        prod.wait_for(state="visible", timeout=15_000)
        prod.click()
        company_page.wait_for_load_state("domcontentloaded", timeout=60_000)

        assert "proddetail" in company_page.url, \
            f"Expected PDP URL. Got: {company_page.url}"

    results.append(check("TC-5547",
        "Verify that user able to land on PDP through company page",
        SUITE, _tc5547))

    # ── TC-5905 ───────────────────────────────────────────────────────────
    # Steps:
    #   1. Go to google.com
    #   2. Search any product
    #   3. Click on the indiamart link in search results
    # Expected: User should land on the PDP page
    # Note: Simulated by navigating directly to the IndiaMART PDP URL
    #       (same as arriving via a Google search result link)
    def _tc5905():
        status = navigate(page, GOOGLE_PDP_URL)
        assert status == 200, \
            f"Expected HTTP 200 from IndiaMART PDP URL. Got: {status}"
        assert "proddetail" in page.url, \
            f"Expected PDP URL. Got: {page.url}"
        # Confirm page has product content
        page.wait_for_selector("h1", timeout=15_000)
        h1 = page.locator("h1").first.inner_text().strip()
        assert len(h1) > 3, f"H1 product title is empty or too short: '{h1}'"

    results.append(check("TC-5905",
        "Verify that user able to land on PDP page through google",
        SUITE, _tc5905))

    # ── TC-5989 ───────────────────────────────────────────────────────────
    # Steps:
    #   1. go to dir.indiamart.com
    #   2. Click on search bar and enter tmt bar
    #   3. Click on first search suggestion
    #   4. Click on first product name under search results (lands on PDP)
    #   5. Click on IndiaMart logo → goes to homepage
    #   6. Click on first product name under 'Products You May Like'
    # Expected: User should land on PDP page
    def _tc5989():
        # Steps 1-4: land on any PDP via search
        land_on_pdp_via_search(page, SEARCH_BASE_URL, SEARCH_KEYWORD)

        # Step 5: Click IndiaMart logo
        logo = page.locator(
            "header a img[alt*='IndiaMART'], "
            "header a img[alt*='indiamart'], "
            "a.logo, "
            "#header a[href*='indiamart.com']:first-child"
        ).first
        logo.wait_for(state="visible", timeout=15_000)
        logo.click()
        page.wait_for_load_state("domcontentloaded", timeout=60_000)

        # Step 6: Click first product under 'Products You May Like'
        # Scroll down to find the section
        page.evaluate("window.scrollTo(0, 600)")
        page.wait_for_timeout(1000)

        may_like_product = page.locator("a[href*='proddetail']").first
        may_like_product.wait_for(state="visible", timeout=15_000)
        may_like_product.scroll_into_view_if_needed()
        may_like_product.click()
        page.wait_for_load_state("domcontentloaded", timeout=60_000)

        assert "proddetail" in page.url, \
            f"Expected PDP URL after homepage navigation. Got: {page.url}"

    results.append(check("TC-5989",
        "Verify that user can able to land on PDP through homepage",
        SUITE, _tc5989))

    return results

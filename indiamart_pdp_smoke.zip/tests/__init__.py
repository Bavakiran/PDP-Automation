# tests package
from tests import test_01_pdp_landings
from tests import test_02_pdp_first_fold
from tests import test_03_pdp_breadcrumbs
from tests import test_04_find_similar_products
from tests import test_05_find_related_categories
from tests import test_06_company_details
from tests import test_07_enquiry_form
from tests import test_08_more_products
from tests import test_09_about_the_company
from tests import test_10_get_quotes
from tests import test_11_header_footer

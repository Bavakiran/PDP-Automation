"""
tests/test_08_more_products.py
────────────────────────────────────────────────────────────────────────────
TestLink Suite : More Products  (id: 458445)
Test Cases     : 2 TCs  →  TC-5953, TC-5954
────────────────────────────────────────────────────────────────────────────
"""
from __future__ import annotations
from playwright.sync_api import Page
from utils.helpers import check, land_on_pdp_via_search
from config import SEARCH_BASE_URL, SEARCH_KEYWORD

SUITE = "More Products"

ENQUIRY_FORM_SEL = (
    ".modal:visible, .popup:visible, .enquiry-form:visible, "
    "[class*='enquiry']:visible, [class*='modal']:visible, "
    "div[role='dialog']:visible, #inquiry_form:visible"
)
MORE_PRODUCTS_SEL = (
    "section:has-text('More Products'), div:has-text('more product from this seller'), "
    "[class*='more-product'], h2:has-text('More Products'), h3:has-text('More Products')"
)
GET_BEST_PRICE_BTN = (
    "button:has-text('Get Best Price'), a:has-text('Get Best Price')"
)


def _go_to_pdp(page: Page) -> None:
    land_on_pdp_via_search(page, SEARCH_BASE_URL, SEARCH_KEYWORD)


def _scroll_to_more_products(page: Page) -> None:
    section = page.locator(MORE_PRODUCTS_SEL).first
    if section.count() > 0:
        section.scroll_into_view_if_needed()
    else:
        page.evaluate("window.scrollTo(0, document.body.scrollHeight * 0.6)")
    page.wait_for_timeout(800)


def run(page: Page) -> list[dict]:
    results: list[dict] = []

    # ── TC-5953 ──────────────────────────────────────────────────────────
    # Verify that more products from the seller is displayed
    def _tc5953():
        _go_to_pdp(page)
        _scroll_to_more_products(page)
        assert (
            page.locator(MORE_PRODUCTS_SEL).count() > 0
            or page.locator("text=/more product/i").count() > 0
        ), "'More products from this seller' section not found"
        # At least one product card inside
        cards = page.locator(
            "a[href*='proddetail']:visible"
        ).count()
        assert cards > 0, "No product cards found in 'More Products' section"

    results.append(check("TC-5953",
        "Verify that more products from the seller is displayed",
        SUITE, _tc5953))

    # ── TC-5954 ──────────────────────────────────────────────────────────
    # Verify that clicking on 'Get Best Price' CTA opens the enquiry form
    def _tc5954():
        _go_to_pdp(page)
        _scroll_to_more_products(page)
        btn = page.locator(GET_BEST_PRICE_BTN).first
        assert btn.is_visible(), "'Get Best Price' CTA not visible in More Products section"
        btn.click()
        page.wait_for_timeout(1500)
        assert page.locator(ENQUIRY_FORM_SEL).count() > 0, \
            "Enquiry form did not open after clicking Get Best Price in More Products"

    results.append(check("TC-5954",
        "Verify that clicking on 'Get Best Price' CTA opens the enquiry form",
        SUITE, _tc5954))

    return results

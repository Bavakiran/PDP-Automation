# ─────────────────────────────────────────────────────────
#  IndiaMart PDP Smoke Test – Configuration
#  Mapped to TestLink Suite ID: 370946
#  Suite: "PDP daily Execution smoke testcases" (39 TCs)
# ─────────────────────────────────────────────────────────

# Fixed PDP used for breadcrumb tests (as specified in TestLink)
BREADCRUMB_PDP_URL = (
    "https://www.indiamart.com/proddetail/"
    "tata-tiscon-10mm-tmt-rebars-2855886579312.html"
)

# Search entry point (used by most landing/first-fold tests)
SEARCH_BASE_URL = "https://dir.indiamart.com"

# Search keyword used across all landing/first-fold TCs
SEARCH_KEYWORD = "tmt bar"

# Google landing PDP (TC 5905)
GOOGLE_PDP_URL = (
    "https://www.indiamart.com/proddetail/"
    "automatic-papad-making-machine-with-dryer-8160460755.html"
)

# Browser / Playwright settings
HEADLESS        = True
VIEWPORT        = {"width": 1440, "height": 900}
TIMEOUT         = 20_000   # element wait (ms)
NAV_TIMEOUT     = 60_000   # navigation wait (ms)
SLOW_MO         = 0        # ms between actions (set >0 for debug)

# User-agent – desktop Chrome
USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/124.0.0.0 Safari/537.36"
)

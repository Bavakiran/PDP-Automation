"""
utils/helpers.py
────────────────────────────────────────────────────────────────────────────
Shared Playwright helpers + HTML report generator.
Every test returns a result dict produced by check() or its wrappers.
────────────────────────────────────────────────────────────────────────────
"""
from __future__ import annotations
import re, time, datetime
from pathlib import Path
from playwright.sync_api import Page, expect


# ── Result dict factory ────────────────────────────────────────────────────
def make_result(tc_id: str, name: str, suite: str,
                status: str, detail: str = "", elapsed: float = 0.0) -> dict:
    return {
        "tc_id":   tc_id,
        "name":    name,
        "suite":   suite,
        "status":  status,          # PASS | FAIL | SKIP
        "detail":  detail,
        "elapsed": round(elapsed * 1000, 1),
    }


# ── Core check wrapper ─────────────────────────────────────────────────────
def check(tc_id: str, name: str, suite: str, fn) -> dict:
    t0 = time.perf_counter()
    try:
        fn()
        return make_result(tc_id, name, suite, "PASS", elapsed=time.perf_counter()-t0)
    except Exception as exc:
        return make_result(tc_id, name, suite, "FAIL",
                           detail=str(exc)[:350], elapsed=time.perf_counter()-t0)


def skip(tc_id: str, name: str, suite: str, reason: str = "") -> dict:
    return make_result(tc_id, name, suite, "SKIP", detail=reason)


# ── Convenience wrappers ───────────────────────────────────────────────────
def visible(page: Page, tc_id: str, name: str, suite: str,
            selector: str, timeout: int = 15_000) -> dict:
    return check(tc_id, name, suite,
                 lambda: expect(page.locator(selector).first)
                         .to_be_visible(timeout=timeout))


def has_text(page: Page, tc_id: str, name: str, suite: str,
             pattern: str, timeout: int = 10_000) -> dict:
    return check(tc_id, name, suite,
                 lambda: expect(page.locator("body"))
                         .to_contain_text(re.compile(pattern, re.I),
                                          timeout=timeout))


def url_contains(page: Page, tc_id: str, name: str, suite: str,
                 fragment: str, timeout: int = 15_000) -> dict:
    return check(tc_id, name, suite,
                 lambda: expect(page).to_have_url(
                     re.compile(re.escape(fragment), re.I), timeout=timeout))


def navigate(page: Page, url: str, timeout: int = 60_000) -> int:
    """Go to URL, return HTTP status code."""
    resp = page.goto(url, wait_until="domcontentloaded", timeout=timeout)
    return resp.status if resp else 0


# ── Common PDP landing flow ────────────────────────────────────────────────
def land_on_pdp_via_search(page: Page,
                            base_url: str = "https://dir.indiamart.com",
                            keyword: str = "tmt bar",
                            timeout: int = 60_000) -> None:
    """
    Exactly mirrors the TestLink steps used across all PDP landing TCs:
      1. go to dir.indiamart.com
      2. Click on the search bar and enter <keyword>
      3. Click on first search suggestion (autocomplete)
      4. Click on first product name under search results
    Raises AssertionError on failure so callers' check() catches it.
    """

    # ── Step 1: go to dir.indiamart.com ──────────────────────────────────
    page.goto(base_url, wait_until="domcontentloaded", timeout=timeout)

    # ── Step 2: Click on search bar and enter keyword ─────────────────────
    search_sel = (
        "input#search_bar_input, "
        "input[name='q'], "
        "input[placeholder*='Search'], "
        "input[type='search']"
    )
    search_box = page.locator(search_sel).first
    search_box.wait_for(state="visible", timeout=timeout)
    search_box.click()
    page.wait_for_timeout(400)
    search_box.fill("")                      # clear any prior value
    search_box.type(keyword, delay=80)       # type slowly → triggers autocomplete

    # ── Step 3: Click on first search suggestion ──────────────────────────
    suggestion_sel = (
        "ul.ui-autocomplete li:first-child, "
        ".autocomplete-suggestions div:first-child, "
        ".suggestion-list li:first-child, "
        "[class*='autocomplete'] li:first-child, "
        "[class*='suggest'] li:first-child, "
        "ul[role='listbox'] li:first-child, "
        ".ac-item:first-child, "
        "div.ui-menu-item:first-child"
    )
    try:
        page.wait_for_selector(suggestion_sel, timeout=5_000)
        page.locator(suggestion_sel).first.click()
        page.wait_for_load_state("domcontentloaded", timeout=timeout)
    except Exception:
        # Autocomplete did not appear – fall back to pressing Enter
        page.keyboard.press("Enter")
        page.wait_for_load_state("domcontentloaded", timeout=timeout)

    # ── Step 4: Click on first product name under search results ──────────
    product_sel = (
        ".product-title a, "
        "h2.prd-name a, "
        "a.prd-name, "
        ".search-result-card a[href*='proddetail'], "
        "a[href*='proddetail']"
    )
    first_product = page.locator(product_sel).first
    first_product.wait_for(state="visible", timeout=timeout)
    first_product.scroll_into_view_if_needed()
    first_product.click()
    page.wait_for_load_state("domcontentloaded", timeout=timeout)

    # ── Confirm we landed on a PDP ────────────────────────────────────────
    assert "proddetail" in page.url, \
        f"Did not land on PDP after search flow. Current URL: {page.url}"


# ── HTML Report Generator ──────────────────────────────────────────────────
_CSS = """
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Segoe UI',Arial,sans-serif;background:#f0f2f5;color:#222}
header{background:linear-gradient(135deg,#1a237e 0%,#283593 100%);
       color:#fff;padding:24px 40px 20px}
header h1{font-size:1.55rem;font-weight:700;letter-spacing:.3px}
header .meta{margin-top:6px;font-size:.85rem;opacity:.8;display:flex;gap:24px;flex-wrap:wrap}
.summary{display:flex;gap:14px;padding:22px 40px;flex-wrap:wrap}
.card{background:#fff;border-radius:10px;padding:18px 26px;min-width:130px;
      box-shadow:0 2px 8px rgba(0,0,0,.09);text-align:center;flex:1;max-width:180px}
.card .num{font-size:2.1rem;font-weight:800}
.card .lbl{font-size:.75rem;color:#777;margin-top:5px;text-transform:uppercase;letter-spacing:.5px}
.c-total .num{color:#1a237e}.c-pass .num{color:#2e7d32}
.c-fail .num{color:#c62828}.c-skip .num{color:#e65100}
.c-pct  .num{font-size:1.5rem;color:#00695c}
.suites{padding:0 40px 40px}
.suite{background:#fff;border-radius:10px;margin-bottom:20px;
       box-shadow:0 2px 8px rgba(0,0,0,.08);overflow:hidden}
.suite-header{background:#e8eaf6;padding:13px 20px;display:flex;
              justify-content:space-between;align-items:center;
              border-bottom:2px solid #c5cae9}
.suite-header h2{font-size:.95rem;color:#1a237e;font-weight:700}
.suite-stats{font-size:.8rem;color:#555;display:flex;gap:14px}
.s-pass{color:#2e7d32;font-weight:600}
.s-fail{color:#c62828;font-weight:600}
table{width:100%;border-collapse:collapse;font-size:.83rem}
th{background:#f5f6fa;padding:10px 14px;text-align:left;font-weight:600;
   color:#444;border-bottom:2px solid #e8eaf6}
td{padding:9px 14px;border-bottom:1px solid #f0f2f5;vertical-align:top}
tr:last-child td{border-bottom:none}
tr:hover td{background:#fafbff}
.badge{display:inline-block;padding:1px 8px;border-radius:10px;
       font-size:.72rem;font-weight:700;background:#e8eaf6;color:#3949ab;
       white-space:nowrap}
.st{display:inline-block;padding:2px 9px;border-radius:5px;
    font-size:.78rem;font-weight:700;white-space:nowrap}
.PASS{background:#e8f5e9;color:#2e7d32}
.FAIL{background:#ffebee;color:#c62828}
.SKIP{background:#fff3e0;color:#e65100}
.tc-name{font-weight:500;color:#222}
.tc-detail{font-size:.76rem;color:#888;margin-top:3px;line-height:1.4;word-break:break-word}
.dur{color:#999;font-size:.78rem;white-space:nowrap}
footer{text-align:center;padding:20px;color:#aaa;font-size:.76rem}
"""

def generate_report(all_results: list[dict], out_path: str) -> None:
    from collections import defaultdict
    grouped: dict[str, list[dict]] = defaultdict(list)
    for r in all_results:
        grouped[r["suite"]].append(r)

    total   = len(all_results)
    passed  = sum(1 for r in all_results if r["status"] == "PASS")
    failed  = sum(1 for r in all_results if r["status"] == "FAIL")
    skipped = sum(1 for r in all_results if r["status"] == "SKIP")
    pct     = round(passed / total * 100) if total else 0
    now     = datetime.datetime.now().strftime("%d %b %Y  %H:%M:%S")

    suite_html = ""
    for suite_name, results in grouped.items():
        sp = sum(1 for r in results if r["status"] == "PASS")
        sf = sum(1 for r in results if r["status"] == "FAIL")
        rows = "".join(f"""
        <tr>
          <td><span class="badge">{r['tc_id']}</span></td>
          <td>
            <div class="tc-name">{r['name']}</div>
            {"" if not r['detail'] else f'<div class="tc-detail">&#9888; {r["detail"]}</div>'}
          </td>
          <td><span class="st {r['status']}">{r['status']}</span></td>
          <td class="dur">{r['elapsed']} ms</td>
        </tr>""" for r in results)

        suite_html += f"""
        <div class="suite">
          <div class="suite-header">
            <h2>{suite_name}</h2>
            <div class="suite-stats">
              <span class="s-pass">&#10003; {sp} passed</span>
              <span class="s-fail">&#10007; {sf} failed</span>
              <span>{len(results)} total</span>
            </div>
          </div>
          <table>
            <thead>
              <tr><th>TC ID</th><th>Test Case</th><th>Status</th><th>Duration</th></tr>
            </thead>
            <tbody>{rows}</tbody>
          </table>
        </div>"""

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>IndiaMart PDP Smoke Report</title>
  <style>{_CSS}</style>
</head>
<body>
<header>
  <h1>&#128722; IndiaMart - PDP Daily Execution Smoke Test Report</h1>
  <div class="meta">
    <span>&#128197; {now}</span>
    <span>&#129514; Suite: PDP daily Execution smoke testcases (TestLink ID: 370946)</span>
    <span>&#127760; indiamart.com</span>
  </div>
</header>
<div class="summary">
  <div class="card c-total"><div class="num">{total}</div><div class="lbl">Total</div></div>
  <div class="card c-pass"> <div class="num">{passed}</div><div class="lbl">Passed</div></div>
  <div class="card c-fail"> <div class="num">{failed}</div><div class="lbl">Failed</div></div>
  <div class="card c-skip"> <div class="num">{skipped}</div><div class="lbl">Skipped</div></div>
  <div class="card c-pct">  <div class="num">{pct}%</div><div class="lbl">Pass Rate</div></div>
</div>
<div class="suites">
{suite_html}
</div>
<footer>IndiaMart PDP Smoke Suite · Playwright + Python · TestLink Suite 370946</footer>
</body></html>"""

    Path(out_path).write_text(html, encoding="utf-8")
    print(f"\n  Report saved: {out_path}")
